$("document").ready(function(){
	
	$("#enter").click(function(){
		$("#landing").toggle( "slow" );
	});

}, false);
