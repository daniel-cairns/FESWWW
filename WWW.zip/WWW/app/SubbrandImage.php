<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SubbrandImage extends Model
{
    public $table = 'subbrands_images';
}
