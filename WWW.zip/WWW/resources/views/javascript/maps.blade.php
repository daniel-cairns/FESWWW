<script src='https://api.mapbox.com/mapbox.js/v2.2.3/mapbox.js'></script>
<script src="https://maps.googleapis.com/maps/api/js?callback=initMap&libraries=places"
        async defer></script>
<script src="/js/maps.js"></script>