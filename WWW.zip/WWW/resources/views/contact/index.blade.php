@extends('master')
@section('title')
	Contact Us
@endsection
@section('content')

<div class="row">
	<div class="columns">
		<h1>Contact</h1>		
	</div>
</div>

@endsection