<body>
	<p>A new booking request and account has been set up for {{ $firstName }} {{ $lastName }}! </p>

	<p>{{ $email }}</p>

	<p>Package {{ $subbrand }} {{ $package }} on {{ $date }} at {{ $address }}</p>
	
</body>