<body>
	<p>Hi there {{ $username }}! </p>

	<p>We are pleased to confirm that your booking has been submitted</p>

	<p>Your Package {{ $subbrand }} {{ $package }} on {{ $date }} at {{ $address }} is currently being handled. We will be in touch as soon as we can to confirm availability for this day.</p>
	
	<p>You can access your new account <a href="http://faredgestudios.co.nz/main.htm">here<a></p>

	<p>Your comments:</p>

	<p>{{ $comments }}</p>

</body>