<body>
	<p>A new booking request and account has been set up for {{ $username }}! </p>

	<p>{{ $email }}</p>

	<p>Package {{ $subbrand }} {{ $package }} on {{ $date }} at {{ $address }}</p>
	
</body>